#if !defined(AFX_COUNTRYVIEW_H__D3482F43_60A2_11D6_A42D_D042B15BD252__INCLUDED_)
#define AFX_COUNTRYVIEW_H__D3482F43_60A2_11D6_A42D_D042B15BD252__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CountryView.h : header file
//

#include <afxcview.h>

/////////////////////////////////////////////////////////////////////////////
// CCountryView view


class CCountryView : public CTreeView
{
protected:
	CCountryView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CCountryView)

// Attributes
public:
	int m_DiffHours;
	int m_DiffMinutes;
	CString m_SelectedCountry;

// Operations
public:
	void UpdateTimer();
	void GetTime(struct tm *ptime);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCountryView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CCountryView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CCountryView)
	afx_msg void OnItemexpanding(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COUNTRYVIEW_H__D3482F43_60A2_11D6_A42D_D042B15BD252__INCLUDED_)
