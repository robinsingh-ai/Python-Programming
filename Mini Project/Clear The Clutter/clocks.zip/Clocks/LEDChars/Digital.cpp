// Digital.cpp : implementation file
//

#include "stdafx.h"
#include "Digital.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDigital

CDigital::CDigital()
{
    time_t t;
    time(&t);
//    tCurrentTime = localtime(&t);
	CTime ct = CTime::GetCurrentTime();
	sTime ="15:40:20:PM"; // ct.Format("%H:%M:%S:%p");
	//    tCurrentTime = CTime::GetCurrentTime();

}

CDigital::~CDigital()
{
}

BEGIN_MESSAGE_MAP(CDigital, CStatic)
	//{{AFX_MSG_MAP(CDigital)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDigital message handlers

void CDigital::SetTime(struct tm *ptm)
{
	CString ampm;
	if(ptm->tm_hour > 12)
	{
		ptm->tm_hour = ptm->tm_hour - 23;
		ampm = "PM";
	}
	else
		ampm = "AM";


	sTime.Format("%2d:%2d:%2d:%s", ptm->tm_hour, ptm->tm_min, ptm->tm_sec , ampm);
	Invalidate(FALSE);
}



void CDigital::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
    CBrush backBrush(RGB(0, 0, 0));

    // Save the old brush
    CBrush* pOldBrush = dc.SelectObject(&backBrush);

    // Get the current clipping boundary
    CRect rect;
    dc.GetClipBox(&rect);

    // Erase the area needed
    dc.PatBlt(rect.left, rect.top, rect.Width(), rect.Height(),
         PATCOPY);

    dc.SelectObject(pOldBrush); // Select the old brush back

	CDC *pDC = CDC::FromHandle(dc.m_ps.hdc);
	DrawingRoutine(pDC);
}

void CDigital::DrawingRoutine(CDC *pDC)
{
	COLORREF clr = RGB(111,235,245);
	int nLeft = 10;
	int nTop = 20;

	if(sTime.Left(1) == " ")
	{
		nLeft += 0;
	}
	else
	{
		DrawCharacter(pDC , CheckSpace(sTime.Left(1)) , nLeft , nTop , clr);
		nLeft += 45;
	}
	DrawCharacter(pDC , sTime.Mid(1,1) , nLeft , nTop , clr);
	nLeft += 45;
	DrawCharacter(pDC , ":" , nLeft , nTop , clr);
	nLeft += 45;
	DrawCharacter(pDC , CheckSpace(sTime.Mid(3,1)) , nLeft , nTop , clr);
	nLeft += 45;
	DrawCharacter(pDC , sTime.Mid(4,1) , nLeft , nTop , clr);
	nLeft += 45;
	DrawCharacter(pDC , ":" , nLeft , nTop , clr);
	nLeft += 45;
	DrawCharacter(pDC , CheckSpace(sTime.Mid(6,1)) , nLeft , nTop , clr);
	nLeft += 45;
	DrawCharacter(pDC , sTime.Mid(7,1) , nLeft , nTop , clr);
	nLeft += 45;
	DrawCharacter(pDC , sTime.Mid(9,1) , nLeft , nTop , clr);
	nLeft += 45;
	DrawCharacter(pDC , "M" , nLeft , nTop , clr);	
}

CString CDigital::CheckSpace(CString s)
{
	return s == " " ? "0" : s;
}

void CDigital::DrawCharacter(CDC *pDC, CString sChar, int nLeft, int nTop, COLORREF clr)
{

	if(sChar == "A")
	{
		pDC->FillSolidRect(nLeft+5  ,nTop+15,   15  ,5, clr); // Top Line
		pDC->FillSolidRect(nLeft    ,nTop+20,  5  ,30, clr); // Left Top
		pDC->FillSolidRect(nLeft+20 ,nTop+20, 5  ,30, clr ); // Right Top
		pDC->FillSolidRect(nLeft+5  ,nTop+32,   15  ,5, clr );  // Central Line
		return;
	}

	if(sChar == "P")
	{
		pDC->FillSolidRect(nLeft+5  ,nTop+15,   15  ,5, clr); // Top Line
		pDC->FillSolidRect(nLeft    ,nTop+20,  5  ,30, clr); // Left Top
		pDC->FillSolidRect(nLeft+20 ,nTop+20, 5  ,12, clr ); // Right Top
		pDC->FillSolidRect(nLeft+5  ,nTop+32,   15  ,5, clr );  // Central Line
		return;
	}

	if(sChar == "M")
	{
		pDC->FillSolidRect(nLeft    ,nTop+15,  15 ,5, clr); // Top Line
		pDC->FillSolidRect(nLeft-5  ,nTop+20,  5  ,30, clr); // Left Top
		pDC->FillSolidRect(nLeft+15 ,nTop+20,  5  ,30, clr ); // Right Top
		pDC->FillSolidRect(nLeft+5  ,nTop+15,  5  ,15, clr ); // Small Line
		return;
	}

	if(sChar == ":")
	{
		pDC->FillSolidRect(nLeft+12 , nTop + 12 , 7, 7,clr);
		pDC->FillSolidRect(nLeft+12 , nTop + 40 ,7, 7,clr);
		return;
	}

	if((sChar == "0") ||
	   (sChar == "2") ||
	   (sChar == "3") ||
	   (sChar == "5") ||
	   (sChar == "6") ||
	   (sChar == "7") ||
	   (sChar == "8") ||
	   (sChar == "9"))
		pDC->FillSolidRect(nLeft,nTop,25,5, clr); // Top Line

	if((sChar == "0") ||
       (sChar == "4") ||
	   (sChar == "5") ||
	   (sChar == "6") ||
	   (sChar == "8") ||
	   (sChar == "9"))
		pDC->FillSolidRect(nLeft-5,nTop+5,5,20, clr); // Left Top

	if((sChar == "0") ||
	   (sChar == "1") ||
	   (sChar == "2") ||
	   (sChar == "3") ||
	   (sChar == "4") ||
	   (sChar == "7") ||
	   (sChar == "8") ||
	   (sChar == "9"))
		pDC->FillSolidRect(nLeft+25,nTop+5,5,20, clr ); // Right Top
	
	if((sChar == "2") ||
	   (sChar == "3") ||
	   (sChar == "4") ||
	   (sChar == "5") ||
	   (sChar == "6") ||
	   (sChar == "8") ||
	   (sChar == "9"))
		pDC->FillSolidRect(nLeft,nTop+25,25,5, clr );  // Central Line
	
	if((sChar == "0") ||
	   (sChar == "2") ||
	   (sChar == "3") ||
	   (sChar == "5") ||
	   (sChar == "6") ||
	   (sChar == "8") ||
	   (sChar == "9"))
		pDC->FillSolidRect(nLeft,nTop+50,25,5, clr );  // Bottom Line

	if((sChar == "0") ||
	   (sChar == "2") ||
	   (sChar == "6") ||
	   (sChar == "8"))
		pDC->FillSolidRect(nLeft-5,nTop+30,5,20, clr ); // Bottom Left

	if((sChar == "0") ||
	   (sChar == "1") ||
	   (sChar == "3") ||
	   (sChar == "4") ||
	   (sChar == "5") ||
	   (sChar == "6") ||
	   (sChar == "7") ||
	   (sChar == "8") ||
	   (sChar == "9"))
		pDC->FillSolidRect(nLeft+25,nTop+30,5,20, clr); // Bottom Right
}

