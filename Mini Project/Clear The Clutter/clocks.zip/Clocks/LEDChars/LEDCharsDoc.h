// LEDCharsDoc.h : interface of the CLEDCharsDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LEDCHARSDOC_H__D3482F2B_60A2_11D6_A42D_D042B15BD252__INCLUDED_)
#define AFX_LEDCHARSDOC_H__D3482F2B_60A2_11D6_A42D_D042B15BD252__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DigitalView.h"
#include "AnalogView.h"

class CLEDCharsDoc : public CDocument
{
protected: // create from serialization only
	CLEDCharsDoc();
	DECLARE_DYNCREATE(CLEDCharsDoc)

// Attributes
public:
	CAnalogView* m_AnalogView;
	CDigitalView* m_DigitalView;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLEDCharsDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLEDCharsDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLEDCharsDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LEDCHARSDOC_H__D3482F2B_60A2_11D6_A42D_D042B15BD252__INCLUDED_)
