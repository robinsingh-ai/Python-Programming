#if !defined(AFX_ANALOGVIEW_H__A18CC981_B07C_11D6_8BD0_B8EF751D4F57__INCLUDED_)
#define AFX_ANALOGVIEW_H__A18CC981_B07C_11D6_8BD0_B8EF751D4F57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AnalogView.h : header file
//

#include "Analog.h"

/////////////////////////////////////////////////////////////////////////////
// CAnalogView view

class CAnalogView : public CView
{
protected:
	CAnalogView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CAnalogView)

// Attributes
public:

// Operations
public:
	void UpdateTime(struct tm *oTime);
	CAnalog m_Analog;
	CString m_Country;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnalogView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CAnalogView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CAnalogView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANALOGVIEW_H__A18CC981_B07C_11D6_8BD0_B8EF751D4F57__INCLUDED_)
