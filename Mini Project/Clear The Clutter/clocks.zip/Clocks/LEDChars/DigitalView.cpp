// DigitalView.cpp : implementation file
//

#include "stdafx.h"
#include "LEDChars.h"
#include "DigitalView.h"

#include "LEDCharsDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDigitalView

IMPLEMENT_DYNCREATE(CDigitalView, CView)

CDigitalView::CDigitalView()
{
}

CDigitalView::~CDigitalView()
{
}

BEGIN_MESSAGE_MAP(CDigitalView, CView)
	//{{AFX_MSG_MAP(CDigitalView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDigitalView drawing

void CDigitalView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CDigitalView diagnostics

#ifdef _DEBUG
void CDigitalView::AssertValid() const
{
	CView::AssertValid();
}

void CDigitalView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDigitalView message handlers


int CDigitalView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CLEDCharsDoc* pDoc = (CLEDCharsDoc*)GetDocument();
	pDoc->m_DigitalView = this;

	m_Digital.Create("", WS_VISIBLE|WS_CHILD, CRect(0,0,450,300), this , ID_ANALOG);
	return 0;
}

void CDigitalView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	if(m_Digital.GetSafeHwnd())
		m_Digital.MoveWindow(0,0,cx,cy,TRUE);
}

void CDigitalView::UpdateTime(struct tm *ptm)
{
	m_Digital.SetTime(ptm);
}



