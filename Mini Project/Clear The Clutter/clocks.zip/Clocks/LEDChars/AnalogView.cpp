// AnalogView.cpp : implementation file
//

#include "stdafx.h"
#include "LEDChars.h"
#include "AnalogView.h"

#include "LEDCharsDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnalogView

IMPLEMENT_DYNCREATE(CAnalogView, CView)

CAnalogView::CAnalogView()
{
}

CAnalogView::~CAnalogView()
{
}


BEGIN_MESSAGE_MAP(CAnalogView, CView)
	//{{AFX_MSG_MAP(CAnalogView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnalogView drawing

void CAnalogView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CAnalogView diagnostics

#ifdef _DEBUG
void CAnalogView::AssertValid() const
{
	CView::AssertValid();
}

void CAnalogView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAnalogView message handlers


int CAnalogView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CLEDCharsDoc* pDoc = (CLEDCharsDoc*)GetDocument();
	pDoc->m_AnalogView = this;

	m_Analog.Create("", WS_VISIBLE|WS_CHILD, CRect(0,0,450,300), this , ID_ANALOG);
	return 0;
}

void CAnalogView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if(m_Analog.GetSafeHwnd())
		m_Analog.MoveWindow(0,0,cx,cy,TRUE);
}


void CAnalogView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
//	UpdateTime();
	CView::OnTimer(nIDEvent);
}


void CAnalogView::OnDestroy() 
{
//	CView::OnDestroy();
	KillTimer(1);	
	// TODO: Add your message handler code here
}

void CAnalogView::UpdateTime(struct tm *oTime)
{
//	struct tm *oTime;
//    time_t t;
//    time(&t);
//	oTime = gmtime(&t);
	m_Analog.m_Country = m_Country;
	m_Analog.SetTime(oTime);
}


