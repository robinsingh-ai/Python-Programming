#if !defined(AFX_ANALOGWATCH_H__A18CC997_B07C_11D6_8BD0_B8EF751D4F57__INCLUDED_)
#define AFX_ANALOGWATCH_H__A18CC997_B07C_11D6_8BD0_B8EF751D4F57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AnalogWatch.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAnalogWatch window

typedef struct tagTIME
  {
    INT     hour;   /* 0 - 11 hours for analog clock */
    INT     hour12; /* 12 hour format */
    INT     hour24; /* 24 hour format */
    INT     minute;
    INT     second;
    INT     ampm;   /* 0 - AM , 1 - PM */
  } TIME;

class CAnalogWatch : public CWnd
{
// Construction
public:
	CAnalogWatch();

// Attributes
public:
	CString m_Country;

	int gDiffMinutes;
	int gDiffHours;

// Operations
public:
	void CreateTools();
	void DeleteTools();

//	void SetCountryTime(CString strCountry, int iHours , int iMinutes);
	void SetTime(struct tm *oTime);

	void ClockSize(register HWND hWnd, INT newWidth, INT newHeight, WORD SizeWord);
	void CompClockDim();
//	void GetTime(TIME *ptime, HDC hDC);
	void CALLBACK MyTimerProc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );
	void DrawHand(register HDC hDC, INT pos, HPEN hPen,  INT scale, INT patMode);
	void DrawFatHand(register HDC hDC, INT pos, HPEN hPen, BOOL hHand);
	void DrawFace(HDC hDC);
	void DrawBorder(HWND hWnd, register HDC hDC);
//	void DeleteTools();
//	void CreateTools();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnalogWatch)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAnalogWatch();

	// Generated message map functions
protected:
	//{{AFX_MSG(CAnalogWatch)
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

	afx_msg void OnSize(UINT nType , int cx , int cy);
	afx_msg void OnDestroy();

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANALOGWATCH_H__A18CC997_B07C_11D6_8BD0_B8EF751D4F57__INCLUDED_)
