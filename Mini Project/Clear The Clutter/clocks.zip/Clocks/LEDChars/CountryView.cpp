/**************************************************************************
   THIS CODE AND INFORMATION IS PROVIDED 'AS IS' WITHOUT WARRANTY OF
   ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
   THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
   PARTICULAR PURPOSE.
   Author: Barretto VN  7/2002
**************************************************************************/

// CountryView.cpp : implementation file
//

#include "stdafx.h"
#include "LEDChars.h"
#include "CountryView.h"

#include "LEDCharsDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCountryView

IMPLEMENT_DYNCREATE(CCountryView, CTreeView)

CCountryView::CCountryView()
{
	m_DiffHours = 0;
	m_DiffMinutes = 0;
}

CCountryView::~CCountryView()
{
}

BEGIN_MESSAGE_MAP(CCountryView, CTreeView)
	//{{AFX_MSG_MAP(CCountryView)
	ON_NOTIFY_REFLECT(TVN_ITEMEXPANDING, OnItemexpanding)
	ON_NOTIFY_REFLECT(TVN_SELCHANGING, OnSelchanging)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCountryView drawing

void CCountryView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CCountryView diagnostics

#ifdef _DEBUG
void CCountryView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CCountryView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCountryView message handlers

BOOL CCountryView::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class

	cs.style  |= TVS_HASBUTTONS | TVS_LINESATROOT | TVS_HASLINES;
	return CTreeView::PreCreateWindow(cs);
}


void CCountryView::OnInitialUpdate() 
{
	CTreeView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	GetTreeCtrl().SetBkColor(RGB(0,0,0));
	GetTreeCtrl().SetTextColor(RGB(111,235,245));

	HTREEITEM hRoot, hItem;
	hRoot = GetTreeCtrl().InsertItem(_T("Countries"), 0,0);

	hItem = GetTreeCtrl().InsertItem(_T("USA (PT)"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, -(8*60));
	hItem = GetTreeCtrl().InsertItem(_T("USA (MT)"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, -(7*60));
	hItem = GetTreeCtrl().InsertItem(_T("USA (CT)"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, -(6*60));
	hItem = GetTreeCtrl().InsertItem(_T("USA (ET)"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, -(5*60));

	hItem = GetTreeCtrl().InsertItem(_T("UK"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, 0);
	hItem = GetTreeCtrl().InsertItem(_T("India"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, 5*60+30);
	hItem = GetTreeCtrl().InsertItem(_T("Australia"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, 10*60+30);
	hItem = GetTreeCtrl().InsertItem(_T("Germany"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, 60);
	hItem = GetTreeCtrl().InsertItem(_T("Hong Kong"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, 7*60);
	hItem = GetTreeCtrl().InsertItem(_T("UAE"), 0,0, hRoot);
	GetTreeCtrl().SetItemData(hItem, 4*60);

	GetTreeCtrl().Expand(hRoot, TVE_EXPAND);

	UpdateTimer();
	SetTimer(0, 1000, NULL); 

}

void CCountryView::OnItemexpanding(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CCountryView::OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here

    HTREEITEM hItem = pNMTreeView->itemNew.hItem;
	m_SelectedCountry = GetTreeCtrl().GetItemText(hItem);

	if(m_SelectedCountry != "Countries")	
	{
		DWORD iData = GetTreeCtrl().GetItemData(hItem);
		m_DiffHours = (int)iData / 60;
		m_DiffMinutes = (int)iData % 60;
	}
	else
		m_SelectedCountry = "GMT";

	*pResult = 0;
}

void CCountryView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	UpdateTimer();
	CTreeView::OnTimer(nIDEvent);
}

void CCountryView::OnDestroy() 
{
	CTreeView::OnDestroy();
	// TODO: Add your message handler code here
	KillTimer(1);	
}

void CCountryView::UpdateTimer()
{
	CLEDCharsDoc* pDoc = (CLEDCharsDoc*)GetDocument();

	struct tm *ptm;
    time_t t;
    time(&t);
	ptm = gmtime(&t);
	ptm->tm_hour = ptm->tm_hour + m_DiffHours+1;
	if(ptm->tm_hour > 23)
		ptm->tm_hour = ptm->tm_hour - 23;

	ptm->tm_min  = ptm->tm_min + m_DiffMinutes;
	if(ptm->tm_min > 60)
		ptm->tm_min=ptm->tm_min - 60;

	pDoc->m_DigitalView->UpdateTime(ptm);

	pDoc->m_AnalogView->UpdateTime(ptm);
	pDoc->m_AnalogView->m_Country = m_SelectedCountry;


}
