// LEDCharsDoc.cpp : implementation of the CLEDCharsDoc class
//

#include "stdafx.h"
#include "LEDChars.h"

#include "LEDCharsDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLEDCharsDoc

IMPLEMENT_DYNCREATE(CLEDCharsDoc, CDocument)

BEGIN_MESSAGE_MAP(CLEDCharsDoc, CDocument)
	//{{AFX_MSG_MAP(CLEDCharsDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLEDCharsDoc construction/destruction

CLEDCharsDoc::CLEDCharsDoc()
{
	// TODO: add one-time construction code here

}

CLEDCharsDoc::~CLEDCharsDoc()
{
}

BOOL CLEDCharsDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CLEDCharsDoc serialization

void CLEDCharsDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CLEDCharsDoc diagnostics

#ifdef _DEBUG
void CLEDCharsDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CLEDCharsDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLEDCharsDoc commands
