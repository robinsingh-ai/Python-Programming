#if !defined(AFX_ANALOGCLOCK_H__D3482F49_60A2_11D6_A42D_D042B15BD252__INCLUDED_)
#define AFX_ANALOGCLOCK_H__D3482F49_60A2_11D6_A42D_D042B15BD252__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AnalogClock.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAnalogClock view

typedef struct tagTIME
  {
    INT     hour;   /* 0 - 11 hours for analog clock */
    INT     hour12; /* 12 hour format */
    INT     hour24; /* 24 hour format */
    INT     minute;
    INT     second;
    INT     ampm;   /* 0 - AM , 1 - PM */
  } TIME;


class CAnalogClock : public CView
{
protected:
	CAnalogClock();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CAnalogClock)

// Attributes
public:
	CString m_Country;

	int gDiffMinutes;
	int gDiffHours;

// Operations
public:
	void SetCountryTime(CString strCountry, int iHours , int iMinutes);
	void SetTime();

	void ClockSize(register HWND hWnd, INT newWidth, INT newHeight, WORD SizeWord);
	void CompClockDim();
	void GetTime(TIME *ptime, HDC hDC);
	void CALLBACK MyTimerProc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );
	void DrawHand(register HDC hDC, INT pos, HPEN hPen,  INT scale, INT patMode);
	void DrawFatHand(register HDC hDC, INT pos, HPEN hPen, BOOL hHand);
	void DrawFace(HDC hDC);
	void DrawBorder(HWND hWnd, register HDC hDC);
	void DeleteTools();
	void CreateTools();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnalogClock)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CAnalogClock();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CAnalogClock)
	afx_msg void OnTimer(UINT nIDEvent);
	
	afx_msg void OnSize(UINT nType , int cx , int cy);
	afx_msg void OnDestroy();


	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANALOGCLOCK_H__D3482F49_60A2_11D6_A42D_D042B15BD252__INCLUDED_)
