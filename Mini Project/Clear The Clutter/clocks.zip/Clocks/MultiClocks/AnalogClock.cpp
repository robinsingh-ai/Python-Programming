// AnalogClock.cpp : implementation file
//

/**************************************************************************
   THIS CODE AND INFORMATION IS PROVIDED 'AS IS' WITHOUT WARRANTY OF
   ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
   THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
   PARTICULAR PURPOSE.
   Author: Barretto VN  7/2002
**************************************************************************/

/******************************************************************************\
*       This is a part of the Microsoft Source Code Samples. 
*       Copyright (C) 1993-1997 Microsoft Corporation.
*       All rights reserved. 
*       This source code is only intended as a supplement to 
*       Microsoft Development Tools and/or WinHelp documentation.
*       See these sources for detailed information regarding the 
*       Microsoft samples programs.
\******************************************************************************/

/*
 *  CLOCK.C - Windows DDEML Clock
 *
 *  DDE Transactions:
 *  ----------------
 *  Service: Clock
 *  Topic  : Time
 *  Item   : Now
 *
 *  Use Request or Advise to get the time or use Poke to change the time.
 *  Time Format Hour:Minute:Seconds where
 *   Hour    = 0-23
 *   Minute  = 0-59
 *   Seconds = 0-59
 */


#include "stdafx.h"
//#include "LEDChars.h"
#include "AnalogClock.h"

#include "clock.h"

//#include "LEDCharsDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


DWORD   idInst = 0;

CLOCKDISPSTRUCT ClockDisp;

HANDLE  hInst;
HWND    hWindow;

HBRUSH  hbrBackground;
HBRUSH  hbrColorWindow;
HBRUSH  hbrColorBlack;
HBRUSH  hbrForeground;
HFONT   hFont;
HPEN    hpenForeground;
HPEN    hpenBackground;

INT     nLeadZero   = 0;
INT     TimerID     = 1;    /* number used for timer-id */
INT     clockRadius;
INT     HorzRes;
INT     VertRes;

LONG    aspectD;
LONG    aspectN;

CHAR    szBuffer[BUFLEN];    /* buffer for stringtable stuff */
CHAR    szFontFile[20];
CHAR    szIniFile[20];
CHAR    szSection[30];

POINT   clockCenter;

RECT    clockRect;
RECT    rCoordRect;


//int gDiffMinutes;
//int gDiffHours;

int gHour;
int gMinute;
int gSecond;

//int gDiffHours;
//int gDiffMinutes;


/////////////////////////////////////////////////////////////////////////////
// CAnalogClock

IMPLEMENT_DYNCREATE(CAnalogClock, CView)

CAnalogClock::CAnalogClock()
{
	clockRect.top    = 200;
	clockRect.bottom = 100;
	clockRect.right  = 300;
	clockRect.left   = 6;

    CreateTools();

	gDiffHours = 0;
	gDiffMinutes = 0;

	m_Country = "GMT";
}

CAnalogClock::~CAnalogClock()
{
}


BEGIN_MESSAGE_MAP(CAnalogClock, CView)
	//{{AFX_MSG_MAP(CAnalogClock)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnalogClock drawing

void CAnalogClock::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here

    CBrush backBrush(RGB(0, 0, 0));

    // Save the old brush
    CBrush* pOldBrush = pDC->SelectObject(&backBrush);

    // Get the current clipping boundary
    CRect rect;
    pDC->GetClipBox(&rect);

    // Erase the area needed
    pDC->PatBlt(rect.left, rect.top, rect.Width(), rect.Height(),
         PATCOPY);

    pDC->SelectObject(pOldBrush); // Select the old brush back

	
}

/////////////////////////////////////////////////////////////////////////////
// CAnalogClock diagnostics

#ifdef _DEBUG
void CAnalogClock::AssertValid() const
{
	CView::AssertValid();
}

void CAnalogClock::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAnalogClock message handlers



void CAnalogClock::CreateTools()
{
  
  hbrForeground  = CreateSolidBrush(RGB(111,235,245)); //GetSysColor(COLOR_WINDOWTEXT));
  hbrColorWindow = CreateSolidBrush(RGB(0,0,0)); //GetSysColor(COLOR_WINDOW));
  hbrColorBlack  = CreateSolidBrush(0L);
  hbrBackground  = hbrColorWindow;
  hpenForeground = CreatePen(0, 1,RGB(111,235,245)); // GetSysColor(COLOR_WINDOWTEXT));
  hpenBackground = CreatePen(0, 1, RGB(111,235,245)); //GetSysColor(COLOR_WINDOW));

  
}

void CAnalogClock::DeleteTools()
{
  DeleteObject(hbrForeground);
  DeleteObject(hbrColorWindow);
  DeleteObject(hbrColorBlack);
  DeleteObject(hpenForeground);
  DeleteObject(hpenBackground);
}


void CAnalogClock::DrawBorder(HWND hWnd, HDC hDC)
{

	RECT Rect;
	HPEN hPen;

	CAnalogClock::GetClientRect((LPRECT) &Rect);

    hPen = CreatePen(PS_SOLID, (ClockDisp.bIconic) ? 1 : 2,
               (ClockDisp.bColor)  ? RGB(255,255,255) : RGB(255,0,0));


//    SelectObject(hDC, hPen);
    Rectangle(hDC, Rect.left+1, Rect.top+1, Rect.right-2, Rect.bottom-2);
//    SelectObject(hDC, GetStockObject(BLACK_PEN));

//    DeleteObject(hPen);

    /* Draw an external black border on an icon without killing the client area. */
    if (ClockDisp.bIconic) {
        MoveToEx(hDC, Rect.left, Rect.top, NULL);
        LineTo(hDC, Rect.left,  Rect.bottom);
        LineTo(hDC, Rect.right, Rect.bottom);
        LineTo(hDC, Rect.right, Rect.top);
        LineTo(hDC, Rect.left,  Rect.top);
    }

}

void CAnalogClock::DrawFace(HDC hDC)
{
	INT        i;
	RECT       tRect;
	INT        blobHeight, blobWidth;

	char c[2];

    blobWidth = (INT)((MAXBLOBWIDTH * (LONG)(clockRect.right - clockRect.left)) / HorzRes);
    blobHeight = (INT)((blobWidth * aspectN) / aspectD);

    if (blobHeight < 2)
        blobHeight = 1;

    if (blobWidth < 2)
        blobWidth = 2;

    InflateRect((LPRECT)&clockRect, -(blobHeight >> 1), -(blobWidth >> 1));

    CRect Rect;
	GetClientRect((LPRECT) &Rect);

//	clockRadius = ((Rect.right - Rect.left) - 50) >> 1 ;
//	clockCenter.y = Rect.top + ((Rect.bottom - Rect.top) >> 1);
//	clockCenter.x = Rect.left + clockRadius+20;
    clockRadius = (Rect.bottom / 2) - 20; // (clockRect.right - clockRect.left-6) >> 1;
    clockCenter.y = Rect.bottom / 2; //clockRect.top + ((clockRect.bottom - clockRect.top) >> 1);
    clockCenter.x = Rect.right / 2; //clockRect.left + clockRadius+3;

    for (i=0; i < 60; i++) {
        tRect.top  = (INT)(((LONG)(CirTab[i].cos) * clockRadius) / CLKSCALE + clockCenter.y);
        tRect.left = (INT)(((LONG)(CirTab[i].sin) * clockRadius) / CLKSCALE + clockCenter.x);

        if (i % 5) {
            /* Draw a dot. */
            if (blobWidth > 2 && blobHeight >= 2) {
                tRect.right = tRect.left + 1;
                tRect.bottom = tRect.top + 1;
                FillRect(hDC, (LPRECT)&tRect, hbrForeground);
            }
        }
        else {
            tRect.right = tRect.left + blobWidth;
            tRect.bottom = tRect.top + blobHeight;
            OffsetRect((LPRECT)&tRect, -(blobWidth >> 1) , -(blobHeight >> 1));
//            FillRect(hDC, (LPRECT)&tRect, hbrForeground);
			if((i / 5) == 0)
				strcpy(c,"12");
			else
				_itoa(i / 5, c  , 10);
	
			SetTextColor(hDC, RGB(255,0,0));
			TextOut(hDC,tRect.left-1,tRect.top-2,c,strlen(c));
			
        }
    }
    InflateRect((LPRECT)&clockRect, (blobHeight >> 1), (blobWidth >> 1));
	SetTextColor(hDC, RGB(145,255,145));
	TextOut(hDC, 10, 10, m_Country, m_Country.GetLength());

}

void CAnalogClock::DrawFatHand(HDC hDC, INT pos, HPEN hPen, BOOL hHand)
{

	register INT    m;
	INT        n;
	INT        scale;
	POINT      tip;
	POINT      stip;

    SetROP2(hDC, R2_COPYPEN);

    SelectObject(hDC, hPen);

    scale = hHand ? 7 : 5;

    n = (pos+15)%60;
    m = (INT)((((LONG)clockRadius*scale) / 100));
    stip.y = (INT)((LONG)(CirTab[n].cos) * m / CLKSCALE);
    stip.x = (INT)((LONG)(CirTab[n].sin) * m / CLKSCALE);

    scale = hHand ? 65 : 80;
    tip.y = (INT)((LONG)(CirTab[pos].cos) * (((LONG)clockRadius * scale) / 100) / CLKSCALE);
    tip.x = (INT)((LONG)(CirTab[pos].sin) * (((LONG)clockRadius * scale) / 100) / CLKSCALE);

    MoveToEx(hDC, clockCenter.x+stip.x, clockCenter.y+stip.y, NULL);
    LineTo(hDC, clockCenter.x+tip.x,  clockCenter.y+tip.y);
    MoveToEx(hDC, clockCenter.x-stip.x, clockCenter.y-stip.y, NULL);
    LineTo(hDC, clockCenter.x+tip.x,  clockCenter.y+tip.y);

    scale = hHand ? 15 : 20;

    n = (pos + 30) % 60;
    m = (INT)(((LONG)clockRadius * scale) / 100);
    tip.y = (INT)((LONG)(CirTab[n].cos) * m / CLKSCALE);
    tip.x = (INT)((LONG)(CirTab[n].sin) * m / CLKSCALE);
    MoveToEx(hDC, clockCenter.x+stip.x, clockCenter.y+stip.y, NULL);
    LineTo(hDC, clockCenter.x+tip.x,  clockCenter.y+tip.y);
    MoveToEx(hDC, clockCenter.x-stip.x, clockCenter.y-stip.y, NULL);
    LineTo(hDC, clockCenter.x+tip.x,  clockCenter.y+tip.y);

}

void CAnalogClock::DrawHand(HDC hDC, INT pos, HPEN hPen, INT scale, INT patMode)
{

	INT       radius;
    MoveToEx(hDC, clockCenter.x, clockCenter.y, NULL);
    radius = (INT)(((LONG)clockRadius * scale) / 100);
    SetROP2(hDC, patMode);
    SelectObject(hDC, hPen);

    LineTo(hDC, clockCenter.x + (INT)(((LONG)(CirTab[pos].sin) * (radius)) / CLKSCALE),
        clockCenter.y + (INT)(((LONG)(CirTab[pos].cos) * (radius)) / CLKSCALE));

}

void CAnalogClock::GetTime(TIME *ptime, HDC hDC)
{
    time_t t;
    struct tm *ptm;

    time(&t);
//    ptm = localtime(&t);

	ptm = gmtime(&t);

	ptm->tm_hour = ptm->tm_hour + gDiffHours+1;
	if(ptm->tm_hour > 23)
		ptm->tm_hour = ptm->tm_hour - 23;

	ptm->tm_min  = ptm->tm_min + gDiffMinutes;
	if(ptm->tm_min > 60)
		ptm->tm_min= ptm->tm_min - 60;

	char sTM[11];
	sprintf(sTM, "%2d:%2d:%2d:%s", ptm->tm_hour , ptm->tm_min, ptm->tm_sec , ptm->tm_hour > 12 ? "PM" : "AM");

	ptime->second = ptm->tm_sec;
    ptime->minute = ptm->tm_min;
    ptime->hour12 =
	ptime->hour =  abs(ptm->tm_hour >= 12 ? ptm->tm_hour - 12 : ptm->tm_hour);
    ptime->hour24 = abs(ptm->tm_hour);
    ptime->ampm = ptm->tm_hour > 12 ? 1 : 0;

	gHour = ptime->hour;
	gMinute = ptime->minute;
	gSecond = ptime->second;

//	CLEDCharsDoc* pDoc = (CLEDCharsDoc*)GetDocument();
//	pDoc->m_DigitalClock->SetTime(sTM);
	
}

void CAnalogClock::CompClockDim()
{
	
	INT        i;
	register INT    tWidth;
	register INT    tHeight;

	if(aspectN == 0)
		return;

    tWidth = clockRect.right - clockRect.left;
    tHeight = clockRect.bottom - clockRect.top;

    if (tWidth > (INT)((tHeight * aspectD) / aspectN)) {
        i = (INT)((tHeight * aspectD) / aspectN);
        clockRect.left += (tWidth - i) >> 1;
        clockRect.right = clockRect.left + i;
    }
    else {
        i = (INT)((tWidth * aspectN) / aspectD);
        clockRect.top += (tHeight - i) >> 1;
        clockRect.bottom = clockRect.top + i;
    }	
}

void CAnalogClock::ClockSize(HWND hWnd, INT newWidth, INT newHeight, WORD SizeWord)
{

    SetRect((LPRECT)&(clockRect), 0, 0, newWidth, newHeight);
    CompClockDim();


    /* Update every 1/2 second in the opened state. */
//    KillTimer(TimerID);
//    SetTimer(TimerID, OPEN_TLEN, 0L);
//    ClockDisp.bIconic = FALSE;
}

void CAnalogClock::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

// TODO: Add your message handler code here
//   ClockSize(this->m_hWnd, LOWORD(lParam), HIWORD(lParam), (WORD)wParam);	

	ClockSize(this->m_hWnd, cx , cy , 0);
}


void CAnalogClock::OnDestroy() 
{
	CView::OnDestroy();

	KillTimer(1);
	DeleteTools();	

	// TODO: Add your message handler code here
}

void CAnalogClock::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
//	CLEDCharsDoc* pDoc = (CLEDCharsDoc*)GetDocument();
//	pDoc->m_AnalogClock = this;
	
	register HDC    hDC;
	INT        HorzSize;
	INT        VertSize;

	CClientDC dc(this);
	hDC = dc.m_hDC;

	VertRes  = dc.GetDeviceCaps(VERTRES);
	HorzRes  = dc.GetDeviceCaps(HORZRES);
    VertSize = dc.GetDeviceCaps(VERTSIZE);
    HorzSize = dc.GetDeviceCaps(HORZSIZE);

    aspectN = ((LONG)VertRes * 100) / (LONG)VertSize;
    aspectD = ((LONG)HorzRes * 100) / (LONG)HorzSize;	

	SetTime();

	SetTimer(0, 1000, NULL); 

	return;
}


void CAnalogClock::SetTime()
{
	RECT    Rect;
	TIME oTime;
	register HDC    hDC;
	HWND hWnd;

	hWnd = this->m_hWnd;
	CClientDC dc(this);
	hDC = dc.m_hDC;

	GetTime(&oTime, hDC);


    GetClientRect((LPRECT) &Rect);

//    rgbCol = GetNearestColor(hDC, GetSysColor(COLOR_WINDOW));
//    hBr = CreateSolidBrush(rgbCol);
//    FillRect(hDC, &Rect, hBr);
//    DeleteObject(hBr);

//    SetBkMode(hDC, OPAQUE);

	SelectObject(hDC, hbrBackground);

    SetBkMode(hDC, TRANSPARENT);

	DrawBorder(hWnd , hDC);

	DrawFace(hDC);

	DrawFatHand(hDC, oTime.minute , hpenForeground,MHAND);

    DrawFatHand(hDC, oTime.hour * 5 + (oTime.minute / 12), hpenForeground, HHAND);

    DrawHand(hDC, oTime.second, hpenForeground, MINUTESCALE, R2_COPYPEN);

//  SetBkMode(hDC, OPAQUE);

}

void CAnalogClock::SetCountryTime(CString strCountry, int iHours , int iMinutes)
{
	m_Country = strCountry;
	gDiffHours = iHours;
	gDiffMinutes = iMinutes;
}

void CAnalogClock::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	SetTime();
	CView::OnTimer(nIDEvent);
}
