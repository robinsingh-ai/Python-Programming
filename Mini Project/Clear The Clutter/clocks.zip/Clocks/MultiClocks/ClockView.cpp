// ClockView.cpp : implementation file
//

#include "stdafx.h"
#include "MultiClocks.h"
#include "ClockView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClockView

IMPLEMENT_DYNCREATE(CClockView, CView)

CClockView::CClockView()
{
	giDiffHrs = 0;
	giDiffMins = 0;

}

CClockView::~CClockView()
{
}


BEGIN_MESSAGE_MAP(CClockView, CView)
	//{{AFX_MSG_MAP(CClockView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClockView drawing

void CClockView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CClockView diagnostics

#ifdef _DEBUG
void CClockView::AssertValid() const
{
	CView::AssertValid();
}

void CClockView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CClockView message handlers


int CClockView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	m_Analog.Create("", WS_VISIBLE|WS_CHILD, CRect(0,0,0,0), this , 0);
	SetTimer(0, 1000, NULL);	
	return 0;
}


void CClockView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if(m_Analog.GetSafeHwnd())
		m_Analog.MoveWindow(0,0,cx,cy,TRUE);
}


void CClockView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	UpdateTime();	
	CView::OnTimer(nIDEvent);
}

void CClockView::OnDestroy() 
{
	CView::OnDestroy();
	
	// TODO: Add your message handler code here
	KillTimer(1);	
}

void CClockView::UpdateTime()
{
	struct tm *ptm;
    time_t t;
    time(&t);
	ptm = gmtime(&t);
	ptm->tm_hour = ptm->tm_hour + giDiffHrs+1;
	if(ptm->tm_hour > 23)
		ptm->tm_hour = ptm->tm_hour - 23;

	ptm->tm_min  = ptm->tm_min + giDiffMins;
	if(ptm->tm_min > 60)
		ptm->tm_min=ptm->tm_min - 60;

	m_Analog.SetTime(ptm);
}

void CClockView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_LOCATION_POPUP));
	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup != NULL);
	POINT pt;
	GetCursorPos(&pt);
	UINT mOptionSelected = pPopup->TrackPopupMenu(TPM_LEFTALIGN |
	   TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, this);
	
	CString caption;
	pPopup->GetMenuString(mOptionSelected , caption, MF_BYCOMMAND );
	SetLocationTime(mOptionSelected, caption);

	CView::OnRButtonDown(nFlags, point);
}

void CClockView::SetLocationTime(UINT uiOption , CString cCountry)
{
	switch(uiOption)
	{
		case IDM_USA_PT:
			giDiffHrs = -8;
			break;
		case IDM_USA_MT:
			giDiffHrs = -7;
			break;
		case IDM_USA_CT:
			giDiffHrs = -6;
			break;
		case IDM_USA_ET:
			giDiffHrs = -5;
			break;
		case IDM_UK:
			giDiffHrs = 0;
			break;
		case IDM_INDIA:
			giDiffHrs = 5;
			giDiffMins = 30;
			break;
		case IDM_AUSTRALIA:
			giDiffHrs = 10;
			giDiffMins = 30;
			break;
		case IDM_UAE:
			giDiffHrs = 4;
			break;
		case IDM_HONG_KONG:
			giDiffHrs = 7;
			break;
		case IDM_GERMANY:
			giDiffHrs = 0;
			break;
	}
	m_Analog.m_Country = cCountry;
}

