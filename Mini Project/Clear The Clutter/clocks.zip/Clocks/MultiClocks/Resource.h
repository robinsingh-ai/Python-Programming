//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MultiClocks.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MULTICTYPE                  129
#define IDR_LOCATION_POPUP              130
#define IDM_USA_PT                      32771
#define IDM_USA_CT                      32772
#define IDM_USA_MT                      32773
#define IDM_USA_ET                      32774
#define IDM_UK                          32775
#define IDM_INDIA                       32776
#define IDM_AUSTRALIA                   32777
#define IDM_GERMANY                     32778
#define IDM_HONG_KONG                   32779
#define IDM_UAE                         32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
