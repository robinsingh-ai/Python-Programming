#if !defined(AFX_ANALOG_H__1AC714E1_B082_11D6_8BD0_B8EF751D4F57__INCLUDED_)
#define AFX_ANALOG_H__1AC714E1_B082_11D6_8BD0_B8EF751D4F57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Analog.h : header file
//

typedef struct tagTIME
  {
    INT     hour;   /* 0 - 11 hours for analog clock */
    INT     hour12; /* 12 hour format */
    INT     hour24; /* 24 hour format */
    INT     minute;
    INT     second;
    INT     ampm;   /* 0 - AM , 1 - PM */
  } TIME;

/////////////////////////////////////////////////////////////////////////////
// CAnalog window

class CAnalog : public CStatic
{
// Construction
public:
	CAnalog();

// Attributes
public:
	CString m_Country;

	int gDiffMinutes;
	int gDiffHours;


// Operations
public:
	void CreateTools();
	void DeleteTools();

//	void SetCountryTime(CString strCountry, int iHours , int iMinutes);
	void SetTime(struct tm *oTime);

	void ClockSize(register HWND hWnd, INT newWidth, INT newHeight, WORD SizeWord);
	void CompClockDim();
//	void GetTime(TIME *ptime, HDC hDC);
	void CALLBACK MyTimerProc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );
	void DrawHand(register HDC hDC, INT pos, HPEN hPen,  INT scale, INT patMode);
	void DrawFatHand(register HDC hDC, INT pos, HPEN hPen, BOOL hHand);
	void DrawFace(HDC hDC);
	void DrawBorder(HWND hWnd, register HDC hDC);
//	void DeleteTools();
//	void CreateTools();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnalog)
	//}}AFX_VIRTUAL

// Implementation
public:
	void InitTime();
	void UpdateClock();
	virtual ~CAnalog();

	// Generated message map functions
protected:
	//{{AFX_MSG(CAnalog)
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANALOG_H__1AC714E1_B082_11D6_8BD0_B8EF751D4F57__INCLUDED_)
